export const SIGN_UP = '/signup';
export const SIGN_IN = '/signin';
export const LANDING = '/landing';
export const HOME = '/home';
