import React from 'react';

const LandingPage = () =>
  <div>
    <h1 style={{color:"white"}}>Hola mundo!!</h1>
    <br></br>
    <br></br>
    <br></br>
    <br></br>
    <br></br>
    <br></br>
    <br></br>
    <br></br>
    <br></br>
    <br></br>
    <br></br>
    <br></br>
    <br></br>
    <br></br>
    <br></br>
    <br></br>
    <br></br>
    <br></br>
  </div>
  
export default LandingPage;